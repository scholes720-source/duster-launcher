package com.ahmadou.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener {

    private static final int REQ_LOCATION = 42;

    private TextView speedTv, timeTv, dateTv, weatherTv;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LocationManager locationManager;
    private double lat = 14.69, lon = -17.44; // Dakar par défaut

    private final SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", Locale.FRENCH);
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE d MMMM", Locale.FRENCH);

    private final Runnable clockTick = new Runnable() {
        @Override
        public void run() {
            Date now = new Date();
            timeTv.setText(timeFmt.format(now));
            dateTv.setText(dateFmt.format(now));
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable weatherTick = new Runnable() {
        @Override
        public void run() {
            fetchWeather();
            handler.postDelayed(this, 15 * 60 * 1000);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable card(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(18));
        return g;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private LinearLayout.LayoutParams weight(float w, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, w);
        p.setMargins(margin, margin, margin, margin);
        return p;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0D0F12"));
        root.setPadding(dp(10), dp(10), dp(10), dp(10));

        // --- Rangée du haut : vitesse + heure/météo ---
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout speedCard = new LinearLayout(this);
        speedCard.setOrientation(LinearLayout.VERTICAL);
        speedCard.setGravity(Gravity.CENTER);
        speedCard.setBackground(card(Color.parseColor("#171A1F")));
        speedTv = text("--", 64, Color.WHITE);
        speedTv.setTypeface(Typeface.DEFAULT_BOLD);
        speedCard.addView(speedTv);
        speedCard.addView(text("km/h", 16, Color.parseColor("#9AA0A8")));
        top.addView(speedCard, weight(1.1f, dp(5)));

        LinearLayout clockCard = new LinearLayout(this);
        clockCard.setOrientation(LinearLayout.VERTICAL);
        clockCard.setGravity(Gravity.CENTER);
        clockCard.setBackground(card(Color.parseColor("#171A1F")));
        timeTv = text("--:--", 44, Color.WHITE);
        timeTv.setTypeface(Typeface.DEFAULT_BOLD);
        dateTv = text("", 16, Color.parseColor("#9AA0A8"));
        weatherTv = text("--°C", 22, Color.parseColor("#F0B84A"));
        clockCard.addView(timeTv);
        clockCard.addView(dateTv);
        clockCard.addView(weatherTv);
        top.addView(clockCard, weight(1f, dp(5)));

        root.addView(top, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.5f));

        // --- Rangée musique : boutons de commande ---
        LinearLayout media = new LinearLayout(this);
        media.setOrientation(LinearLayout.HORIZONTAL);
        media.addView(mediaButton("<<", KeyEvent.KEYCODE_MEDIA_PREVIOUS), weight(1f, dp(5)));
        media.addView(mediaButton("Lecture / Pause", KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE), weight(2f, dp(5)));
        media.addView(mediaButton(">>", KeyEvent.KEYCODE_MEDIA_NEXT), weight(1f, dp(5)));
        root.addView(media, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.8f));

        // --- Rangée du bas : applications ---
        LinearLayout apps = new LinearLayout(this);
        apps.setOrientation(LinearLayout.HORIZONTAL);
        apps.addView(tile("W", "Waze", "#4AA8F0", "com.waze"), weight(1f, dp(5)));
        apps.addView(tile("M", "Maps", "#5FCF80", "com.google.android.apps.maps"), weight(1f, dp(5)));
        apps.addView(tile("S", "Spotify", "#1DB954", "com.spotify.music"), weight(1f, dp(5)));
        apps.addView(tile("Y", "YT Music", "#F05A5A", "com.google.android.apps.youtube.music"), weight(1f, dp(5)));
        apps.addView(allAppsTile(), weight(1f, dp(5)));
        root.addView(apps, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.2f));

        setContentView(root);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        askLocationPermission();
    }

    private View mediaButton(String label, final int keyCode) {
        TextView b = text(label, 20, Color.WHITE);
        b.setBackground(card(Color.parseColor("#171A1F")));
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
                am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
            }
        });
        return b;
    }

    private View tile(String letter, String label, String colorHex, final String pkg) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setBackground(card(Color.parseColor("#171A1F")));

        TextView icon = text(letter, 26, Color.WHITE);
        icon.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.parseColor(colorHex));
        icon.setBackground(circle);
        t.addView(icon, new LinearLayout.LayoutParams(dp(56), dp(56)));

        TextView l = text(label, 14, Color.WHITE);
        l.setPadding(0, dp(6), 0, 0);
        t.addView(l);

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launch(pkg);
            }
        });
        return t;
    }

    private View allAppsTile() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setBackground(card(Color.parseColor("#171A1F")));

        TextView icon = text("+", 30, Color.WHITE);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.parseColor("#3A3F47"));
        icon.setBackground(circle);
        t.addView(icon, new LinearLayout.LayoutParams(dp(56), dp(56)));

        TextView l = text("Toutes", 14, Color.WHITE);
        l.setPadding(0, dp(6), 0, 0);
        t.addView(l);

        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAllApps();
            }
        });
        return t;
    }

    private void launch(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            Toast.makeText(this, "Application non installée", Toast.LENGTH_LONG).show();
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void showAllApps() {
        final PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        final List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
        Collections.sort(list, new Comparator<ResolveInfo>() {
            @Override
            public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });
        List<String> names = new ArrayList<>();
        for (ResolveInfo r : list) names.add(r.loadLabel(pm).toString());
        names.add("Réglages Android");

        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Toutes les applications")
                .setItems(names.toArray(new String[0]), new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == list.size()) {
                            Intent s = new Intent(Settings.ACTION_SETTINGS);
                            s.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(s);
                            return;
                        }
                        ResolveInfo r = list.get(which);
                        Intent i = new Intent(Intent.ACTION_MAIN);
                        i.addCategory(Intent.CATEGORY_LAUNCHER);
                        i.setClassName(r.activityInfo.packageName, r.activityInfo.name);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    }
                })
                .show();
    }

    // ---------- Position / vitesse ----------

    private void askLocationPermission() {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
        } else {
            startLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_LOCATION && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) {
            startLocation();
        }
    }

    private void startLocation() {
        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, this);
            Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last != null) {
                lat = last.getLatitude();
                lon = last.getLongitude();
            }
        } catch (SecurityException | IllegalArgumentException e) {
            speedTv.setText("--");
        }
    }

    @Override
    public void onLocationChanged(Location loc) {
        lat = loc.getLatitude();
        lon = loc.getLongitude();
        if (loc.hasSpeed()) {
            int kmh = Math.round(loc.getSpeed() * 3.6f);
            speedTv.setText(String.valueOf(kmh));
        }
    }

    @Override public void onStatusChanged(String p, int s, Bundle e) { }
    @Override public void onProviderEnabled(String p) { }
    @Override public void onProviderDisabled(String p) { }

    // ---------- Météo (Open-Meteo, gratuit, sans clé) ----------

    private void fetchWeather() {
        final double la = lat, lo = lon;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("https://api.open-meteo.com/v1/forecast?latitude=" + la
                            + "&longitude=" + lo + "&current=temperature_2m");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                    r.close();
                    double temp = new JSONObject(sb.toString())
                            .getJSONObject("current").getDouble("temperature_2m");
                    final String out = Math.round(temp) + "°C";
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            weatherTv.setText(out);
                        }
                    });
                } catch (Exception e) {
                    // pas d'internet : on laisse l'ancienne valeur
                }
            }
        }).start();
    }

    // ---------- Cycle de vie ----------

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(clockTick);
        handler.post(weatherTick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(clockTick);
        handler.removeCallbacks(weatherTick);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            locationManager.removeUpdates(this);
        } catch (Exception ignored) { }
    }

    @Override
    public void onBackPressed() {
        // Un launcher ne se ferme pas avec le bouton retour.
    }
}
